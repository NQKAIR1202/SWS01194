<!DOCTYPE html> 
<html>
    
    <title>Job Description</title>
    <div class="ontop">
        <a href="index.php"><img src="logo/logo.png" class="companylogo" alt="InfiniTech Labs logo"></a>
        <a href="https://www.youtube.com/watch?v=dxuAZFVHZfg" target="_blank">
            <img src="logo/logo youtube.png" alt="Youtube logo" class="youtube-logo">
        </a>
        
    </div>
    <link rel="stylesheet" href="style3.css">

    
    <section>
   
    </section>
        
        <body>
            <h1 class="topen">THIS IS WHERE WE WORK</h1>
            <p class="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1385.5540666533984!2d106.66866173844618!3d10.816002823783872!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752ff6c51d5ebd%3A0x4403e126c229b92b!2sSwinburne%20Vietnam%20Alliance%20Program%20-%20HCMC%20location!5e0!3m2!1svi!2s!4v1740053549667!5m2!1svi!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </p>
        
       <h2>Address:</h2>
            <h3>A35 Bach Dang, Ward 2, Tan Binh, Ho Chi Minh</h3> <br><br>

    <div><a href ="enhancements2.php" class="game">Feel tired of waiting for our responsed?</a> </div>
           
            <br><br><br>
        </body>
        <a href="index.php" class="back-button"><img src="logo/back-button.png" alt="BackButton"></a>
</html>