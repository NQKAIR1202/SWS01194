<!DOCTYPE html>
<lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style6.css">
    <title>Enhancement 2</title>
    </head>
<body>

<input type="checkbox" id="trybrowser" autocomplete="off" />
<input type="radio" name="state" id="state_restart" checked="checked" autocomplete="off" /><input type="radio" name="state" id="state_play-active" autocomplete="off" /><input type="radio" name="state" id="state_life2-active" autocomplete="off" /><input type="radio" name="state" id="state_life1-active" autocomplete="off" /><input type="radio" name="state" id="state_lose" autocomplete="off" />
<input type="radio" name="score" id="score1" autocomplete="off" /><input type="radio" name="score" id="score2" autocomplete="off" /><input type="radio" name="score" id="score3" autocomplete="off" /><input type="radio" name="score" id="score4" autocomplete="off" /><input type="radio" name="score" id="score5" autocomplete="off" /><input type="radio" name="score" id="score6" checked="checked" autocomplete="off" />
<form autocomplete="off">
<input type="radio" name="wave" id="wave0" checked="checked" /><input type="radio" name="wave" id="wave1" /><input type="radio" name="wave" id="wave2" />
<input type="radio" name="miss" id="miss-0" /><input type="radio" name="miss" id="miss-1" />
<input type="radio" name="ufo-0" id="ufo-0" checked="checked" /><input type="radio" name="ufo-1" id="ufo-1" checked="checked" />
<input type="radio" name="inv0-0" id="inv0-0" checked="checked" /><input type="radio" name="inv0-1" id="inv0-1" checked="checked" /><input type="radio" name="inv0-2" id="inv0-2" checked="checked" /><input type="radio" name="inv0-3" id="inv0-3" checked="checked" /><input type="radio" name="inv0-4" id="inv0-4" checked="checked" />
<input type="radio" name="inv0-5" id="inv0-5" checked="checked" /><input type="radio" name="inv0-6" id="inv0-6" checked="checked" /><input type="radio" name="inv0-7" id="inv0-7" checked="checked" /><input type="radio" name="inv0-8" id="inv0-8" checked="checked" /><input type="radio" name="inv0-9" id="inv0-9" checked="checked" /><input type="radio" name="inv0-10" id="inv0-10" checked="checked" />
<input type="radio" name="inv1-11" id="inv1-11" checked="checked" /><input type="radio" name="inv1-12" id="inv1-12" checked="checked" /><input type="radio" name="inv1-13" id="inv1-13" checked="checked" /><input type="radio" name="inv1-14" id="inv1-14" checked="checked" /><input type="radio" name="inv1-15" id="inv1-15" checked="checked" />
<input type="radio" name="inv1-16" id="inv1-16" checked="checked" /><input type="radio" name="inv1-17" id="inv1-17" checked="checked" /><input type="radio" name="inv1-18" id="inv1-18" checked="checked" /><input type="radio" name="inv1-19" id="inv1-19" checked="checked" /><input type="radio" name="inv1-20" id="inv1-20" checked="checked" /><input type="radio" name="inv1-21" id="inv1-21" checked="checked" />
<input type="radio" name="inv2-22" id="inv2-22" checked="checked" /><input type="radio" name="inv2-23" id="inv2-23" checked="checked" /><input type="radio" name="inv2-24" id="inv2-24" checked="checked" /><input type="radio" name="inv2-25" id="inv2-25" checked="checked" /><input type="radio" name="inv2-26" id="inv2-26" checked="checked" />
<input type="radio" name="inv2-27" id="inv2-27" checked="checked" /><input type="radio" name="inv2-28" id="inv2-28" checked="checked" /><input type="radio" name="inv2-29" id="inv2-29" checked="checked" /><input type="radio" name="inv2-30" id="inv2-30" checked="checked" /><input type="radio" name="inv2-31" id="inv2-31" checked="checked" /><input type="radio" name="inv2-32" id="inv2-32" checked="checked" />
<input type="radio" name="inv3-33" id="inv3-33" checked="checked" /><input type="radio" name="inv3-34" id="inv3-34" checked="checked" /><input type="radio" name="inv3-35" id="inv3-35" checked="checked" /><input type="radio" name="inv3-36" id="inv3-36" checked="checked" /><input type="radio" name="inv3-37" id="inv3-37" checked="checked" />
<input type="radio" name="inv3-38" id="inv3-38" checked="checked" /><input type="radio" name="inv3-39" id="inv3-39" checked="checked" /><input type="radio" name="inv3-40" id="inv3-40" checked="checked" /><input type="radio" name="inv3-41" id="inv3-41" checked="checked" /><input type="radio" name="inv3-42" id="inv3-42" checked="checked" /><input type="radio" name="inv3-43" id="inv3-43" checked="checked" />
<input type="radio" name="inv4-44" id="inv4-44" checked="checked" /><input type="radio" name="inv4-45" id="inv4-45" checked="checked" /><input type="radio" name="inv4-46" id="inv4-46" checked="checked" /><input type="radio" name="inv4-47" id="inv4-47" checked="checked" /><input type="radio" name="inv4-48" id="inv4-48" checked="checked" />
<input type="radio" name="inv4-49" id="inv4-49" checked="checked" /><input type="radio" name="inv4-50" id="inv4-50" checked="checked" /><input type="radio" name="inv4-51" id="inv4-51" checked="checked" /><input type="radio" name="inv4-52" id="inv4-52" checked="checked" /><input type="radio" name="inv4-53" id="inv4-53" checked="checked" /><input type="radio" name="inv4-54" id="inv4-54" checked="checked" />
<input type="radio" name="ufo-0" id="hitufo-0" /><input type="radio" name="ufo-1" id="hitufo-1" />
<input type="radio" name="inv0-0" id="hit0-0" /><input type="radio" name="inv0-1" id="hit0-1" /><input type="radio" name="inv0-2" id="hit0-2" /><input type="radio" name="inv0-3" id="hit0-3" /><input type="radio" name="inv0-4" id="hit0-4" />
<input type="radio" name="inv0-5" id="hit0-5" /><input type="radio" name="inv0-6" id="hit0-6" /><input type="radio" name="inv0-7" id="hit0-7" /><input type="radio" name="inv0-8" id="hit0-8" /><input type="radio" name="inv0-9" id="hit0-9" /><input type="radio" name="inv0-10" id="hit0-10" />
<input type="radio" name="inv1-11" id="hit1-11" /><input type="radio" name="inv1-12" id="hit1-12" /><input type="radio" name="inv1-13" id="hit1-13" /><input type="radio" name="inv1-14" id="hit1-14" /><input type="radio" name="inv1-15" id="hit1-15" />
<input type="radio" name="inv1-16" id="hit1-16" /><input type="radio" name="inv1-17" id="hit1-17" /><input type="radio" name="inv1-18" id="hit1-18" /><input type="radio" name="inv1-19" id="hit1-19" /><input type="radio" name="inv1-20" id="hit1-20" /><input type="radio" name="inv1-21" id="hit1-21" />
<input type="radio" name="inv2-22" id="hit2-22" /><input type="radio" name="inv2-23" id="hit2-23" /><input type="radio" name="inv2-24" id="hit2-24" /><input type="radio" name="inv2-25" id="hit2-25" /><input type="radio" name="inv2-26" id="hit2-26" />
<input type="radio" name="inv2-27" id="hit2-27" /><input type="radio" name="inv2-28" id="hit2-28" /><input type="radio" name="inv2-29" id="hit2-29" /><input type="radio" name="inv2-30" id="hit2-30" /><input type="radio" name="inv2-31" id="hit2-31" /><input type="radio" name="inv2-32" id="hit2-32" />
<input type="radio" name="inv3-33" id="hit3-33" /><input type="radio" name="inv3-34" id="hit3-34" /><input type="radio" name="inv3-35" id="hit3-35" /><input type="radio" name="inv3-36" id="hit3-36" /><input type="radio" name="inv3-37" id="hit3-37" />
<input type="radio" name="inv3-38" id="hit3-38" /><input type="radio" name="inv3-39" id="hit3-39" /><input type="radio" name="inv3-40" id="hit3-40" /><input type="radio" name="inv3-41" id="hit3-41" /><input type="radio" name="inv3-42" id="hit3-42" /><input type="radio" name="inv3-43" id="hit3-43" />
<input type="radio" name="inv4-44" id="hit4-44" /><input type="radio" name="inv4-45" id="hit4-45" /><input type="radio" name="inv4-46" id="hit4-46" /><input type="radio" name="inv4-47" id="hit4-47" /><input type="radio" name="inv4-48" id="hit4-48" />
<input type="radio" name="inv4-49" id="hit4-49" /><input type="radio" name="inv4-50" id="hit4-50" /><input type="radio" name="inv4-51" id="hit4-51" /><input type="radio" name="inv4-52" id="hit4-52" /><input type="radio" name="inv4-53" id="hit4-53" /><input type="radio" name="inv4-54" id="hit4-54" />
<input type="radio" name="shield0-0" id="shield0-0" checked="checked" /><input type="radio" name="shield0-0" id="shieldhit0-0" /><input type="radio" name="shield0-1" id="shield0-1" checked="checked" /><input type="radio" name="shield0-1" id="shieldhit0-1" /><input type="radio" name="shield0-2" id="shield0-2" checked="checked" /><input type="radio" name="shield0-2" id="shieldhit0-2" /><input type="radio" name="shield0-3" id="shield0-3" checked="checked" /><input type="radio" name="shield0-3" id="shieldhit0-3" /><input type="radio" name="shield0-4" id="shield0-4" checked="checked" /><input type="radio" name="shield0-4" id="shieldhit0-4" /><input type="radio" name="shield0-5" id="shield0-5" checked="checked" /><input type="radio" name="shield0-5" id="shieldhit0-5" /><input type="radio" name="shield0-6" id="shield0-6" checked="checked" /><input type="radio" name="shield0-6" id="shieldhit0-6" />
<input type="radio" name="shield1-0" id="shield1-0" checked="checked" /><input type="radio" name="shield1-0" id="shieldhit1-0" /><input type="radio" name="shield1-1" id="shield1-1" checked="checked" /><input type="radio" name="shield1-1" id="shieldhit1-1" /><input type="radio" name="shield1-2" id="shield1-2" checked="checked" /><input type="radio" name="shield1-2" id="shieldhit1-2" /><input type="radio" name="shield1-3" id="shield1-3" checked="checked" /><input type="radio" name="shield1-3" id="shieldhit1-3" /><input type="radio" name="shield1-4" id="shield1-4" checked="checked" /><input type="radio" name="shield1-4" id="shieldhit1-4" /><input type="radio" name="shield1-5" id="shield1-5" checked="checked" /><input type="radio" name="shield1-5" id="shieldhit1-5" /><input type="radio" name="shield1-6" id="shield1-6" checked="checked" /><input type="radio" name="shield1-6" id="shieldhit1-6" />
<input type="radio" name="shield2-0" id="shield2-0" checked="checked" /><input type="radio" name="shield2-0" id="shieldhit2-0" /><input type="radio" name="shield2-1" id="shield2-1" checked="checked" /><input type="radio" name="shield2-1" id="shieldhit2-1" /><input type="radio" name="shield2-2" id="shield2-2" checked="checked" /><input type="radio" name="shield2-2" id="shieldhit2-2" /><input type="radio" name="shield2-3" id="shield2-3" checked="checked" /><input type="radio" name="shield2-3" id="shieldhit2-3" /><input type="radio" name="shield2-4" id="shield2-4" checked="checked" /><input type="radio" name="shield2-4" id="shieldhit2-4" /><input type="radio" name="shield2-5" id="shield2-5" checked="checked" /><input type="radio" name="shield2-5" id="shieldhit2-5" /><input type="radio" name="shield2-6" id="shield2-6" checked="checked" /><input type="radio" name="shield2-6" id="shieldhit2-6" />
<input type="radio" name="shield3-0" id="shield3-0" checked="checked" /><input type="radio" name="shield3-0" id="shieldhit3-0" /><input type="radio" name="shield3-1" id="shield3-1" checked="checked" /><input type="radio" name="shield3-1" id="shieldhit3-1" /><input type="radio" name="shield3-2" id="shield3-2" checked="checked" /><input type="radio" name="shield3-2" id="shieldhit3-2" /><input type="radio" name="shield3-3" id="shield3-3" checked="checked" /><input type="radio" name="shield3-3" id="shieldhit3-3" /><input type="radio" name="shield3-4" id="shield3-4" checked="checked" /><input type="radio" name="shield3-4" id="shieldhit3-4" /><input type="radio" name="shield3-5" id="shield3-5" checked="checked" /><input type="radio" name="shield3-5" id="shieldhit3-5" /><input type="radio" name="shield3-6" id="shield3-6" checked="checked" /><input type="radio" name="shield3-6" id="shieldhit3-6" />
<input type="radio" name="pos" id="pos0" /><input type="radio" name="pos" id="pos1" /><input type="radio" name="pos" id="pos2" /><input type="radio" name="pos" id="pos3" /><input type="radio" name="pos" id="pos4" />
<input type="radio" name="pos" id="pos5" /><input type="radio" name="pos" id="pos6" /><input type="radio" name="pos" id="pos7" /><input type="radio" name="pos" id="pos8" /><input type="radio" name="pos" id="pos9" />
<input type="radio" name="pos" id="pos10" /><input type="radio" name="pos" id="pos11" /><input type="radio" name="pos" id="pos12" /><input type="radio" name="pos" id="pos13" /><input type="radio" name="pos" id="pos14" />
<input type="radio" name="pos" id="pos15" /><input type="radio" name="pos" id="pos16" /><input type="radio" name="pos" id="pos17" /><input type="radio" name="pos" id="pos18" /><input type="radio" name="pos" id="pos19" />
<input type="radio" name="pos" id="pos20" /><input type="radio" name="pos" id="pos21" /><input type="radio" name="pos" id="pos22" checked="checked" /><input type="radio" name="pos" id="pos23" /><input type="radio" name="pos" id="pos24" />
<input type="radio" name="pos" id="pos25" /><input type="radio" name="pos" id="pos26" /><input type="radio" name="pos" id="pos27" /><input type="radio" name="pos" id="pos28" /><input type="radio" name="pos" id="pos29" />
<input type="radio" name="pos" id="pos30" /><input type="radio" name="pos" id="pos31" /><input type="radio" name="pos" id="pos32" /><input type="radio" name="pos" id="pos33" /><input type="radio" name="pos" id="pos34" />
<input type="radio" name="pos" id="pos35" /><input type="radio" name="pos" id="pos36" /><input type="radio" name="pos" id="pos37" /><input type="radio" name="pos" id="pos38" /><input type="radio" name="pos" id="pos39" />
<input type="radio" name="pos" id="pos40" /><input type="radio" name="pos" id="pos41" /><input type="radio" name="pos" id="pos42" /><input type="radio" name="pos" id="pos43" /><input type="radio" name="pos" id="pos44" />
<input type="reset" id="reset" />
<div id="game">
<p id="hiscoreText" class="game">High</p>
<p id="scoreText" class="game">Score</p>
<p id="livesText" class="game">Lives</p>
<div id="lives" class="game">
<div></div><div></div><div></div>
</div>
<div id="ufo0" class="game"></div>
<div id="ufo1" class="game"></div>
<div id="shields" class="game"><div><div>
<div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
<div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
<div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
<div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
</div></div></div>
<div id="wave" class="game">
<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>
<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>
<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>
<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>
<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>
</div>
<div id="land" class="game"></div>
<div id="base" class="game"></div>
<div id="controls" class="game">
<div class="arrows"><div></div><div class="arrow2"></div><div class="arrow3"></div><div class="arrow4"></div></div>
<div class="arrows arrowsr"><div></div><div class="arrow2"></div><div class="arrow3"></div><div class="arrow4"></div></div>
<div class="arrows arrowsu"><div></div><div class="arrow2"></div><div class="arrow3"></div><div class="arrow4"></div></div>
<div id="move">
<div>
<label for="pos0"></label><label for="pos1"></label><label for="pos2"></label><label for="pos3"></label><label for="pos4"></label>
<label for="pos5"></label><label for="pos6"></label><label for="pos7"></label><label for="pos8"></label><label for="pos9"></label>
<label for="pos10"></label><label for="pos11"></label><label for="pos12"></label><label for="pos13"></label><label for="pos14"></label>
<label for="pos15"></label><label for="pos16"></label><label for="pos17"></label><label for="pos18"></label><label for="pos19"></label>
<label for="pos20"></label><label for="pos21"></label><label for="pos22"></label><label for="pos23"></label><label for="pos24"></label>
<label for="pos25"></label><label for="pos26"></label><label for="pos27"></label><label for="pos28"></label><label for="pos29"></label>
<label for="pos30"></label><label for="pos31"></label><label for="pos32"></label><label for="pos33"></label><label for="pos34"></label>
<label for="pos35"></label><label for="pos36"></label><label for="pos37"></label><label for="pos38"></label><label for="pos39"></label>
<label for="pos40"></label><label for="pos41"></label><label for="pos42"></label><label for="pos43"></label><label for="pos44"></label>
</div>
</div>
<div id="fire">
<div>
<label for="miss-0"></label><label for="miss-1"></label>
<label for="hitufo-0"></label><label for="hitufo-1"></label>
<div class="inv-labels"><label for="hit0-0"></label><label for="hit0-1"></label><label for="hit0-2"></label><label for="hit0-3"></label><label for="hit0-4"></label>
<label for="hit0-5"></label><label for="hit0-6"></label><label for="hit0-7"></label><label for="hit0-8"></label><label for="hit0-9"></label><label for="hit0-10"></label></div>
<div class="inv-labels"><label for="hit1-11"></label><label for="hit1-12"></label><label for="hit1-13"></label><label for="hit1-14"></label><label for="hit1-15"></label>
<label for="hit1-16"></label><label for="hit1-17"></label><label for="hit1-18"></label><label for="hit1-19"></label><label for="hit1-20"></label><label for="hit1-21"></label></div>
<div class="inv-labels"><label for="hit2-22"></label><label for="hit2-23"></label><label for="hit2-24"></label><label for="hit2-25"></label><label for="hit2-26"></label>
<label for="hit2-27"></label><label for="hit2-28"></label><label for="hit2-29"></label><label for="hit2-30"></label><label for="hit2-31"></label><label for="hit2-32"></label></div>
<div class="inv-labels"><label for="hit3-33"></label><label for="hit3-34"></label><label for="hit3-35"></label><label for="hit3-36"></label><label for="hit3-37"></label>
<label for="hit3-38"></label><label for="hit3-39"></label><label for="hit3-40"></label><label for="hit3-41"></label><label for="hit3-42"></label><label for="hit3-43"></label></div>
<div class="inv-labels"><label for="hit4-44"></label><label for="hit4-45"></label><label for="hit4-46"></label><label for="hit4-47"></label><label for="hit4-48"></label>
<label for="hit4-49"></label><label for="hit4-50"></label><label for="hit4-51"></label><label for="hit4-52"></label><label for="hit4-53"></label><label for="hit4-54"></label></div>
<div class="shield-labels"><div><div><div><label for="shieldhit0-0"></label><label for="shieldhit0-1"></label><label for="shieldhit0-2"></label><label for="shieldhit0-3"></label><label for="shieldhit0-4"></label></div>
<div><label for="shieldhit0-5"></label><label for="shieldhit0-6"></label></div></div>
<div><div><label for="shieldhit1-0"></label><label for="shieldhit1-1"></label><label for="shieldhit1-2"></label><label for="shieldhit1-3"></label><label for="shieldhit1-4"></label></div>
<div><label for="shieldhit1-5"></label><label for="shieldhit1-6"></label></div></div>
<div><div><label for="shieldhit2-0"></label><label for="shieldhit2-1"></label><label for="shieldhit2-2"></label><label for="shieldhit2-3"></label><label for="shieldhit2-4"></label></div>
<div><label for="shieldhit2-5"></label><label for="shieldhit2-6"></label></div></div>
<div><div><label for="shieldhit3-0"></label><label for="shieldhit3-1"></label><label for="shieldhit3-2"></label><label for="shieldhit3-3"></label><label for="shieldhit3-4"></label></div>
<div><label for="shieldhit3-5"></label><label for="shieldhit3-6"></label></div></div></div></div>
</div>
</div>
</div>
<div id="landed0" class="game"><label for="state_lose"></label><label for="state_life1-active"></label><label for="state_life2-active"></label><label for="wave2"></label><label for="wave1"></label></div>
<div id="landed1" class="game"><label for="state_lose"></label><label for="state_life1-active"></label><label for="state_life2-active"></label><label for="wave2"></label><label for="wave1"></label></div>
<div id="landed2" class="game"><label for="state_lose"></label><label for="state_life1-active"></label><label for="state_life2-active"></label><label for="wave2"></label><label for="wave1"></label></div>
<div id="landed3" class="game"><label for="state_lose"></label><label for="state_life1-active"></label><label for="state_life2-active"></label><label for="wave2"></label><label for="wave1"></label></div>
<div id="landed4" class="game"><label for="state_lose"></label><label for="state_life1-active"></label><label for="state_life2-active"></label><label for="wave2"></label><label for="wave1"></label></div>
<div id="cleared" class="game"><label for="reset"></label><label for="wave2"></label></div>
<div id="restart" class="game"><label for="reset"></label></div>
<ol id="hiscores">
<li id="high1">
<ul class="tenthousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="thousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="hundreds"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="tens"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul><li></li></ul>
</li>
<li id="high2">
<ul class="tenthousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="thousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="hundreds"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="tens"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul><li></li></ul>
</li>
<li id="high3">
<ul class="tenthousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="thousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="hundreds"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="tens"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul><li></li></ul>
</li>
<li id="high4">
<ul class="tenthousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="thousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="hundreds"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="tens"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul><li></li></ul>
</li>
<li id="high5">
<ul class="tenthousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="thousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="hundreds"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="tens"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul><li></li></ul>
</li>
<li id="high6">
<ul class="tenthousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="thousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="hundreds"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="tens"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul><li></li></ul>
</li>
</ol>
<p>*Hiscores*</p>
<div id="score">
<ul class="tenthousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="thousands"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="hundreds"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul class="tens"><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>
<ul><li></li></ul>
</div>
<div id="gameover">
<div id="go1"><label for="state_restart"></label><label for="wave1"></label><label for="score1"></label></div>
<div id="go2"><label for="state_restart"></label><label for="wave1"></label><label for="score2"></label></div>
<div id="go3"><label for="state_restart"></label><label for="wave1"></label><label for="score3"></label></div>
<div id="go4"><label for="state_restart"></label><label for="wave1"></label><label for="score4"></label></div>
<div id="go5"><label for="state_restart"></label><label for="wave1"></label><label for="score5"></label></div>
<div id="go6"><label for="state_restart"></label><label for="wave1"></label><label for="score6"></label></div>
</div>
</div>
<div id="title">
<div id="text"><h1></h1><h1></h1><h1></h1></div>
<label for="state_play-active">Press To Play</label>
<label for="reset"></label>
<p id="pointText">*Score Advance Table*</p>
<ol id="points"><li>=? Mystery</li><li>=10 Points</li><li>=10 Points</li><li>=10 Points</li></ol>
<a id="tryother" target="_blank" href="/jonslater204/pen/PopQbrz">Try basic version</a>
</div>
<div id="browsercheck"><div><p>Your browser may not support all the features of this version</p><a target="_blank" href="/jonslater204/pen/PopQbrz">Play other version</a><label for="trybrowser">Try this version</label></div></div>
</form>

    </body>

    <a href="index.php" class="back-button"><img src="logo/back-button.png" alt="BackButton"></a>
    
</html>